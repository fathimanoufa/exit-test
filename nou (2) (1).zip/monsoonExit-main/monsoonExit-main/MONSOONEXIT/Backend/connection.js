const mongoose = require("mongoose");
mongoose
  .connect(
    "mongodb+srv://kmnoufa2004:WLQzSmYVnA4yMTV7@cluster0.ccoehoa.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0+srv://123ajithachu:NYOFUgi6uO3mrQxr@cluster0.1se4baj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
    {}
  )
  .then(() => {
    console.log("Connected to DB");
  })
  .catch((error) => {
    console.log(error);
  });
